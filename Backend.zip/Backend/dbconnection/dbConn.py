import os
from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base



load_dotenv()


DATABASE_URL = os.getenv("DATABASE_URL")

Base =declarative_base()
engine = create_engine(DATABASE_URL)

try:
    with engine.connect() as conn:
        print("Connection to SQL Server successful!")
except Exception as e:
    print(" Connection failed:", e)
