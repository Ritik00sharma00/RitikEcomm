from flask import Flask, jsonify, request
from flask_cors import CORS, cross_origin
from flask import jsonify,request
from sqlalchemy.orm import sessionmaker
from controller.admin_controller import avg_rating_by_category, categorized_orders, fetch_all_users, get_order_details
from controller.order_controller import cancel_order, create_order, get_orders_with_product_details
from controller.product_controller import get_product, fetch_all_products,fetchAllCategories,fetchSubcategoriesByCategory, products_by_category, products_by_category_and_price, products_by_subcategory,products_by_price,products_by_subcategory_and_price
from model.product_model import Product
from model.user_model import User
from dbconnection.dbConn import engine
import requests
from flask import Flask
from controller.user_controller import  login, signup_function
from controller.cart_controller import add_to_cart, fetch_all_cart_products, update_the_cart
from flask_jwt_extended import JWTManager, create_access_token, jwt_required

from dotenv import load_dotenv
import os
from functools import wraps


load_dotenv()
app = Flask(__name__)


CORS(app,supports_credentials=True)




app.config['JWT_SECRET_KEY'] =  os.getenv("JWT_SECRET_KEY", "default_secret_key")

jwt = JWTManager(app)

EXCLUDED_ROUTES = ['/login', '/signup', '/public']  

@app.route('/')
@cross_origin()
def home():
    return "Welcome to the E-Commerce Application!"

def should_skip_auth(path):
    """Check if the current path should skip authentication"""
    return any(path == route or path.startswith(route) for route in EXCLUDED_ROUTES)


  

@app.route('/signup',methods=['POST'])
@cross_origin()
@jwt_required(optional=True)
def signup_route():
    data=request.get_json()
    name=data.get('name')
    email=data.get('email')
    password=data.get('password')
    mobileNumber=data.get('mobileNumber')
    age=data.get('age')
    address=data.get('address')
    city=data.get('city')
    gender=data.get('gender')
    return signup_function(name,email,password,mobileNumber,age,address,city,gender)
    
# name,email,password,mobileNumber,age,address

@app.route('/login',methods=['POST'])
@cross_origin()
@jwt_required(optional=True)
def login_route():
    data=request.get_json()
    email=data.get('email')
    print("JWT_SECRET_KEY:", app.config['JWT_SECRET_KEY'])
    password=data.get('password')
    return login(email,password)



from flask_jwt_extended import verify_jwt_in_request, get_jwt

@app.before_request
def before_request():
    """Middleware to handle authentication."""
    if request.method == "OPTIONS":
        return '', 200  

    
    if request.path in EXCLUDED_ROUTES:
        return 
    token = request.headers.get('Authorization')  
    # print(token)
    try:
        
        verify_jwt_in_request()  # Flask-JWT function to verify token
        decoded_token = get_jwt()  # Get decoded token data
        print("Decoded Token:", decoded_token)  # Debugging
    except Exception as e:
        return jsonify({'msg': 'Token is invalid or missing', 'error': str(e)}), 401  # Unauthorized





Session=sessionmaker(bind=engine)
session=Session()


######################################################################## Product Routes ############################################
@app.route('/products', methods=['GET'])
@jwt_required()
@cross_origin()
def get_all_products():
    """Fetch all products."""
    return fetch_all_products()

@app.route('/products/category/<string:category>', methods=['GET'])
@jwt_required()
@cross_origin()
def get_products_by_category(category):
    """Fetch products by category."""
    return products_by_category(category)



@app.route('/products/id/<product_id>', methods=['GET'])
@jwt_required()
@cross_origin()
def get_products_by_id(product_id):
    """Fetch products by ID."""
    return get_product(product_id)



@app.route('/products/price/<low>/<high>', methods=['GET'])
@jwt_required()
@cross_origin()
def get_products_by_price(low, high):
    """Fetch products by price range."""
    return products_by_price(low, high)



@app.route('/products/subcategory/<subcategory>',methods=['GET'])
@jwt_required
@cross_origin
def get_products_by_subcat(subcategory):
    return products_by_category(subcategory)



@app.route('/products/price_category/<low>/<high>/<category>', methods=['GET'])
@jwt_required()
@cross_origin()
def get_products_by_price_and_category(low, high, category):
    """Fetch products by price range and category."""
    return products_by_category_and_price(category,low,high)





# #################################################################### Cart Routes ########################################################
@app.route('/cart/add/<userid>/<productid>',methods=['POST'])
@jwt_required()
@cross_origin()
def add_to_cart_route(userid,productid):
    return add_to_cart(userid,productid)



@app.route('/cart/update/<cartItemId>/<productId>/<int:quantity>',methods=['POST'])
@jwt_required()
@cross_origin()
def update_the_cart_route(cartItemId, productId, quantity):
    return update_the_cart(cartItemId, productId, quantity)



@app.route('/fetch-carts/<int:user_id>',methods=['GET'])
@jwt_required()
@cross_origin()
def fetch_the_carts_route(user_id):
    return fetch_all_cart_products(user_id)







@app.route('/fetch-products', methods=['GET'])
@jwt_required()
def fetch_products():
    api_url = "https://fakestoreapi.com/products"
    try:
        response = requests.get(api_url)
        response.raise_for_status()
        products = response.json()  

        for product in products:
            new_product = Product(
                id=product['id'],
                title=product['title'],
                price=product['price'],
                description=product['description'],
                category=product['category'],
                image=product['image'],
                rating=product['rating']['rate'],
                sold_items=product['rating']['count']
            )
            
            session.add(new_product)  
        session.commit()
        return {"message": "Products fetched and stored successfully"}, 200

    except requests.exceptions.RequestException as e:
        return {"error": str(e)}, 500
    except Exception as e:
        return {"error": "Failed to store products: " + str(e)}, 500


@app.route('/fetchcatgeories',methods=['GET'])
@jwt_required()
@cross_origin()
def fetchcategories():
    return fetchAllCategories()



@app.route('/products/subcategories/<subcategory>',methods=['GET'])
@jwt_required()
@cross_origin()
def fetchsubcategoryProducts(subcategory):
    return products_by_subcategory(subcategory)



@app.route('/fetchsubcatgeories/<category>',methods=['GET'])
@jwt_required()
@cross_origin()
def fetchsubcategories(category):
    return fetchSubcategoriesByCategory(category)





@app.route('/products/subcategory/price/<subcategory>/<low>/<high>',methods=['GET'])
@jwt_required()
@cross_origin()
def fetchsubcategpryandPrice(subcategory,low,high):
    return products_by_subcategory_and_price(subcategory, low, high)





# ###################################### Order routes #################################

@app.route('/order/create',methods=['POST'])
@jwt_required()
def create_order_route():
    request_data=request.get_json()
    result = create_order(request_data)
    return result



@app.route('/fetchallorders/<userid>',methods=['GET'])
@jwt_required()
@cross_origin()
def fetch_orders_by_userid(userid):
    return get_orders_with_product_details(userid)


@app.route('/order/cancel/<orderid>',methods=['PUT'])
@jwt_required()
@cross_origin()
def cancelorder(orderid):
    return cancel_order(orderid)

#----------------------------------------------------------------Admin controls-----------------------------#

@app.route('/admin/product_rating_analysis',methods=['GET'])
@jwt_required()
@cross_origin()
def avg_category_rating():
    return avg_rating_by_category()



@app.route('/admin/fetchusers',methods=['GET'])
@jwt_required(optional=True)
@cross_origin()
def fetchallusrsfucntion():
    return fetch_all_users()


@app.route('/admin/fetchallorders',methods=['GET'])
@jwt_required(optional=True)
@cross_origin()
def fetchorders():
    return get_order_details()


@app.route('/categorizedOrders',methods=['GET'])
@jwt_required(optional=True)
@cross_origin()
def categorizedorders():
    return categorized_orders()

if __name__ == '__main__':
    app.run(debug=True)
