from sqlalchemy.orm import sessionmaker
from flask import jsonify
from model.centralizedmodel import Product
from dbconnection.dbConn import engine

Session = sessionmaker(bind=engine)
session = Session()

def fetch_all_products():
    try:
        products = session.query(Product).all()
        
        product_list = [
            {
                "productId": product.productId,
                "name": product.name,
                "description": product.description,
                "imageUrl": product.imageUrl,
                "price":product.price,
                "category": product.category,
                "subcategory": product.subcategory,
                "inventory": product.inventory,
                "rating": product.rating,
                "itemsSold": product.itemsSold,
                "dimensions": product.dimensions,
                "createdAt": product.createdAt,
                "updatedAt": product.updatedAt
            }
            for product in products
        ]
        
        return jsonify({"success": True, "products": product_list})
    
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500
    
    finally:
        session.close()





def products_by_category_and_price(category, low, high):
    try:
        # Query for products by category and price range
        categorized_products = session.query(Product).filter(
            Product.category == category,
            Product.price >= low,
            Product.price <= high
        ).all()

        # Format the response with product details
        product_list = [
            {
                "productId": product.productId,
                "name": product.name,
                "description": product.description,
                "imageUrl": product.imageUrl,
                "category": product.category,
                "price":product.price,
                "subcategory": product.subcategory,
                "inventory": product.inventory,
                "rating": product.rating,
                "itemsSold": product.itemsSold,
                "dimensions": product.dimensions,
                "createdAt": product.createdAt,
                "updatedAt": product.updatedAt
            }
            for product in categorized_products
        ]

        # Return the product data
        return jsonify({"success": True, "products": product_list}), 200
    except Exception as e:
        # Handle any exceptions by returning a 500 error
        return jsonify({"success": False, "message": str(e)}), 500


# Fetch products by category
def products_by_category(category):
    try:
        categorized_products = session.query(Product).filter(Product.category == category).all()

        product_list = [
            {
                "productId": product.productId,
                "name": product.name,
                "description": product.description,
                "price":product.price,
                "imageUrl": product.imageUrl,
                "category": product.category,
                "subcategory": product.subcategory,
                "inventory": product.inventory,
                "rating": product.rating,
                "itemsSold": product.itemsSold,
                "dimensions": product.dimensions,
                "createdAt": product.createdAt,
                "updatedAt": product.updatedAt
            }
            for product in categorized_products
        ]

        return jsonify({"success": True, "products": product_list}), 200
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

# Fetch products by price range
def products_by_price(low, high):
    try:
        priced_products = session.query(Product).filter(Product.price >= low, Product.price <= high).all()

        product_list = [
            {
                "productId": product.productId,
                "name": product.name,
                "description": product.description,
                "price":product.price,
                "imageUrl": product.imageUrl,
                "category": product.category,
                "subcategory": product.subcategory,
                "inventory": product.inventory,
                "rating": product.rating,
                "itemsSold": product.itemsSold,
                "dimensions": product.dimensions,
                "createdAt": product.createdAt,
                "updatedAt": product.updatedAt
            }
            for product in priced_products
        ]
        
        return jsonify({"success": True, "products": product_list}), 200
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


def products_by_subcategory_and_price(subcategory, low, high):
    try:
        filtered_products = session.query(Product).filter(
            Product.subcategory == subcategory,
            Product.price >= low,
            Product.price <= high
        ).all()

        product_list = [
            {
                "productId": product.productId,
                "name": product.name,
                "description": product.description,
                "price":product.price,
                "imageUrl": product.imageUrl,
                "category": product.category,
                "subcategory": product.subcategory,
                "inventory": product.inventory,
                "rating": product.rating,
                "itemsSold": product.itemsSold,
                "dimensions": product.dimensions,
                "createdAt": product.createdAt,
                "updatedAt": product.updatedAt
            }
            for product in filtered_products
        ]

        return jsonify({"success": True, "products": product_list}), 200
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

# Fetch products by subcategory
def products_by_subcategory(subcategory):
    try:
        categorized_products = session.query(Product).filter(Product.subcategory == subcategory).all()

        product_list = [
            {
                "productId": product.productId,
                "name": product.name,
                "description": product.description,
                "imageUrl": product.imageUrl,
                "category": product.category,
                "subcategory": product.subcategory,
                "inventory": product.inventory,
                "rating": product.rating,
                "itemsSold": product.itemsSold,
                "dimensions": product.dimensions,
                "createdAt": product.createdAt,
                "updatedAt": product.updatedAt
            }
            for product in categorized_products
        ]
       
        return jsonify({"success": True, "products": product_list}), 200
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500



def get_product(product_id):
    try:
        product = session.query(Product).filter(Product.productId == product_id).first()

        if not product:
            return jsonify({"msg": "Product not found"}), 404

        return jsonify({
            "productId": product.productId,
            "name": product.name,
            "description": product.description,
            "imageUrl": product.imageUrl,
            "category": product.category,
            "subcategory": product.subcategory,
            "inventory": product.inventory,
            "rating": product.rating,
            "itemsSold": product.itemsSold,
            "dimensions": product.dimensions,
            "price": product.price,
        })
    except Exception as e:
        return jsonify({"msg": "Error fetching product", "error": str(e)}), 500
    

def fetchAllCategories():
   
    categories_name = session.query(Product.category).distinct().all()
   
    categories_list = [category[0] for category in categories_name]
    
    return jsonify({"success":True,"categories":categories_list})


def fetchSubcategoriesByCategory(category_name):
 
    subcategories_name = (
        session.query(Product.subcategory)
        .filter(Product.category == category_name)
        .distinct()
        .all()
    )

  
    subcategories_list = [subcategory[0] for subcategory in subcategories_name]

    return jsonify({"success":True,"subcategories":subcategories_list})
