from flask import jsonify
from sqlalchemy import func 
from sqlalchemy.orm import sessionmaker
from dbconnection.dbConn import engine
from model.centralizedmodel import Order
from model.centralizedmodel import Product
from model.centralizedmodel import User


Session =sessionmaker(bind=engine)
session=Session()


def avg_rating_by_category():
    # query=session.query(Product.category,func.round(func.avg(Product.rating),2).label("average_category"),func.count(Product.id).label("total_products")).group_by(Product.category).order_by(func.round(func.avg(Product.rating),2))
    query = (
    session.query(
        Product.category,
        func.round(func.avg(func.coalesce(Product.rating, 0)), 2).label("average_rating"),
        func.count(Product.productId).label("total_products")
    )
    .group_by(Product.category)
    .order_by(func.round(func.avg(func.coalesce(Product.rating, 0)), 2).desc()).all() # Sort by avg rating descending
)
    session.commit()
    session.close()


    try:
        
        formatted_result = [
            {
                "category": row.category,
                "average_rating": row.average_rating,
                "total_products": row.total_products
            }
            for row in query
        ]
        return jsonify({"result":formatted_result})
    
    except Exception as e:
        return jsonify({"error":e})




def fetch_all_users():
   
    try:
        query=session.query(User).order_by(User.name).all()
        
        all_users=[
        {
            "name":user.name,
            "age":user.age,
            "email":user.email,
            "gender":user.gender,
            "city":user.city,
            "id":user.id

        }
        for user in query
        ]
        return jsonify({"users":all_users}),200
    except Exception as e:
        return jsonify({"error":str(e)})



def delete_user_by_id(user_id):
    try:
            deleted_rows = session.query(User).filter(User.id == user_id).delete()
            session.commit()

            if deleted_rows:
                return jsonify({"message": "User deleted successfully"}), 200
            else:
                return jsonify({"error": "User not found"}), 404

    except Exception as e:
        return jsonify({"error": str(e)}), 500



def get_order_details():
    try:
        with Session() as session:
            orders = (
                session.query(
                    Order.id.label("order_id"),
                    Order.order_date,
                    Order.delivered_on,
                    Order.payment_status,
                    Order.status,
                    Order.total_price,
                    Order.order_location.label("city"),
                    User.id.label("user_id"),
                    User.name.label("user_name"),
                    User.email.label("user_email"), 
                    Product.productId.label("product_id"),
                    Product.name.label("product_name"),
                )
                .join(User, Order.userid == User.id)
                .join(Product, Order.product_id == Product.productId)
                .all()
            )

            order_list = [
                {
                    "order_id": order.order_id,
                    "user_email":order.user_email,
                    "user_id": order.user_id,
                    "product_id": order.product_id,
                    "product_name": order.product_name,
                    "order_date": order.order_date.strftime("%Y-%m-%d %H:%M:%S") if order.order_date else None,
                    "delivered_on": order.delivered_on.strftime("%Y-%m-%d %H:%M:%S") if order.delivered_on else None,
                    "payment_status": order.payment_status,
                    "status": order.status,
                    "total_price": float(order.total_price) if order.total_price else 0.0,
                    "city": order.city
                }
                for order in orders
            ]

        return jsonify({"orders": order_list}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500  
    



def categorized_orders():
    try:
            orders_count_18_30 = (
                session.query(
                    Product.category,
                    func.count(Order.id).label("order_count")
                )
                .join(User, Order.userid == User.id)
                .join(Product, Order.product_id == Product.productId)
                .filter((User.age >= 18) & (User.age <= 30))
                .group_by(Product.category)
                .all()
            )

            orders_count_30_50 = (
                session.query(
                    Product.category,
                    func.count(Order.id).label("order_count")
                )
                .join(User, Order.userid == User.id)
                .join(Product, Order.product_id == Product.productId)
                .filter((User.age > 30) & (User.age <= 50))
                .group_by(Product.category)
                .all()
            )

            orders18_serialized = [{"category": row[0], "order_count": row[1]} for row in orders_count_18_30]
            orders30_serialized = [{"category": row[0], "order_count": row[1]} for row in orders_count_30_50]

            return jsonify({"orders18": orders18_serialized, "orders30": orders30_serialized})

    except Exception as e:
        return jsonify({"error": str(e)})
