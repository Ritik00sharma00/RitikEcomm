import os
from dotenv import load_dotenv
from flask import jsonify, request
from dbconnection.dbConn import engine, Base
from sqlalchemy.orm import sessionmaker
from datetime import datetime
from model.centralizedmodel import Product  # Assuming you have a Product model to reference
import traceback
Session = sessionmaker(bind=engine)
session = Session()
from datetime import datetime
from sqlalchemy.orm import sessionmaker
from dbconnection.dbConn import engine
from model.centralizedmodel import Order
from model.centralizedmodel import Product
import stripe
Session = sessionmaker(bind=engine)
session = Session()


load_dotenv()

stripe.api_key = os.getenv("STRIPE_SECRET_KEY")

def create_order(request_data):
    try:
        data = request_data
        userid = data.get("userid")
        product_id = data.get("product_id")
        quantity = data.get("quantity")
        payment_mode = data.get("payment_mode")
        order_location = data.get("order_location")
        payment_mode=data.get("payment_mode")
        delivered_on=data.get("delivered_on")
        status=data.get("status")
        total_price=data.get('price')
        
        product = session.query(Product).filter(Product.productId == product_id).first()
        if not product:
            return jsonify({"error": "Product not found."}), 404

        total_price = product.price * quantity

        if payment_mode == "card":
            try:
                
                payment_intent = stripe.PaymentIntent.create(
                    amount=int(total_price * 100),  
                    currency="usd",
                    payment_method_types=["card"],
                )
                client_secret = payment_intent.client_secret
            except Exception as e:
                return jsonify({"error": str(e)}), 500
        else:
            client_secret = None  

        new_order = Order(
            userid=userid,
            product_id=product_id,
            quantity=quantity,
            total_price=total_price,
            status=status,
            order_date=datetime.utcnow(),
            delivered_on=delivered_on,
            order_location=order_location,
            payment_mode=payment_mode,
            payment_status="Completed"
        )

        session.add(new_order)
        session.commit()

        return jsonify({
            "message": "Order created successfully",
            "order_id": new_order.id,
            "client_secret": client_secret  # Send client secret for Stripe checkout
        })

    except Exception as e:
        session.rollback()
        print(e)
        return jsonify({"error": str(e)}), 500
    finally:
        session.close()






def get_orders_with_product_details(user_id):
    try:
        orders = (
            session.query(
                Order, Product.name, Product.imageUrl, Product.price  # Fetch name, image, price
            )
            .join(Product, Order.product_id == Product.productId)  # Join Order & Product tables
            .filter(Order.userid == user_id)
            .all()
        )

        order_list = [
            {
                "order_id": order.id,
                "user_id": order.userid,
                "product_id": order.product_id,
                "status": order.status,
                "product_name": product_name,
                "product_image": product_image,  # Include product image
                "order_date": order.order_date,
                "quantity": order.quantity,
                "total_price": order.quantity * product_price  # Calculate total price
            }
            for order, product_name, product_image, product_price in orders  # Unpack values
        ]

        return jsonify({"orders": order_list}), 200

    except Exception as e:
        print(str(e))
        return jsonify({"error": str(e)}), 500






def cancel_order(order_id):
    try:
        order = session.query(Order).filter(Order.id == order_id).first()

        if not order:
            return {"error": "Order not found."}

        order.status = "Declined"
        session.commit()

        return {"message": f"Order with ID {order_id} has been declined."}

    except Exception as e:
        session.rollback()
        return {"error": str(e)}

    finally:
        session.close()
