from flask import jsonify,request

from datetime import timedelta
from sqlalchemy.orm import sessionmaker
from model.centralizedmodel import User
from dbconnection.dbConn import engine
import bcrypt
from flask_jwt_extended import create_access_token



def hash_password(password): 
    salt = bcrypt.gensalt()
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed_password



def verify_password(provided_password, stored_password):
    if isinstance(stored_password, str):
        stored_password = stored_password.encode('utf-8')  
    return bcrypt.checkpw(provided_password.encode('utf-8'), stored_password)





Session=sessionmaker(bind=engine)
session=Session()


def signup_function(name,email,password,mobileNumber,age,address,city,gender):
    existing_query=session.query(User).filter(User.email==email).first()

    if  existing_query:
        return jsonify("The email is already registered"),404
    else:

        user=User(name=name,email=email,password=hash_password(password),mobileNumber=mobileNumber,age=age,address=address,city=city,gender=gender)
        session.add(user)
        session.commit()
    
    return jsonify("User added siccessfull"),200




def login(email, password):
    existing_query = session.query(User).filter(User.email == email).first()

    if not existing_query:
        return jsonify({"msg": "The email is not registered"}), 404
    
    if verify_password(password, existing_query.password):
        user_data = {
            "id": existing_query.id,
            "name": existing_query.name,
            "email": existing_query.email,
            "mobileNumber": existing_query.mobileNumber,
            "address": existing_query.address,
            "role":existing_query.role
        }

        
        access_token = create_access_token(identity=existing_query.email, expires_delta=timedelta(hours=1))

        
       
        return jsonify({
            "message": "You are logged in",
            "user": user_data,
            "access_token":access_token 
        }), 200
    
    
    return jsonify({"msg": "Incorrect credentials"}), 402          



    
