from flask import jsonify
from dbconnection.dbConn import engine
from sqlalchemy.orm import sessionmaker
# from model.cart_model import Cart
# from model.cart_items_model import CartItem
from model.centralizedmodel import Product
from model.centralizedmodel import Cart,CartItem
from sqlalchemy.exc import SQLAlchemyError
# from model.cart_items_model import CartItem


Session = sessionmaker(bind=engine)
session=Session()



def add_to_cart(userid, productid):
    try:
        # Check if the user already has a cart
        existing_cart = session.query(Cart).filter_by(userId=userid).first()
        print(existing_cart)
        
        if not existing_cart:
            # If the user doesn't have a cart, create a new one
            new_cart = Cart(userId=userid)
            session.add(new_cart)
            session.flush()  # Use flush to get the cartId before commit
            
            # Ensure the cartId is available after flush
            print(f"New cart created with cartId: {new_cart.cartId}")
            
            # Now the cartId will be available after flush
            cart_item = CartItem(cartId=new_cart.cartId, productId=productid, quantity=1)
            session.add(cart_item)
        
        else:
            # If the cart exists, check if the product is already in the cart
            existing_product = (
                session.query(CartItem)
                .filter_by(cartId=existing_cart.cartId, productId=productid)
                .first()
            )
            print("Product check:", existing_product)
            
            if not existing_product:
                # If the product is not in the cart, add it as a new item
                cart_item = CartItem(cartId=existing_cart.cartId, productId=productid, quantity=1)
                session.add(cart_item)
            else:
                # If the product exists, increase the quantity by 1
                existing_product.quantity += 1
        
        # Commit the transaction once after all changes
        session.commit()
        return jsonify({"message": "Product added to cart successfully"})

    except SQLAlchemyError as e:
        session.rollback()  # Rollback if any error occurs
        return jsonify({"error": f"Database error: {str(e)}"})
    except Exception as e:
        session.rollback()  # Rollback on other errors
        return jsonify({"error": f"Error: {str(e)}"})
    


def update_the_cart(cartItemId, productId, quantity):
    try:
        cart_item = session.query(CartItem).filter(CartItem.cartItemId == cartItemId).first()
        product_check=session.query(Product).filter(Product.productId== productId).first()
        # Check if the cart item exists

        if not cart_item:   
            print(f"Cart item with ID {cartItemId} does not exist.")
            return

        if quantity == 0:
            session.delete(cart_item)
            session.commit()
            print(f"Cart item with ID {cartItemId} has been removed.")
        else:
            cart_item.productId = productId
            cart_item.quantity = quantity
            session.commit()
            return jsonify({"message":"Cart item with ID {cartItemId} has been updated with product ID {productId} and quantity {quantity}.","inventory":{product_check.inventory}}),200    
        session.commit()
        return jsonify({"message":"success"}),200
    
    except Exception as e:
        session.rollback()
        return jsonify({"error":str(e)})
    finally:
        session.close()








def fetch_all_cart_products(user_id):
    try:
        # Fetch the cart for the given user
        cart = session.query(Cart).filter(Cart.userId == user_id).first()

        if not cart:
            return {"message": "No cart found for this user.", "products": []}

        # Fetch all cart items and associated products
        cart_items = (
            session.query(CartItem, Product)
            .join(Product, CartItem.productId == Product.productId)
            .filter(CartItem.cartId == cart.cartId)
            .all()
        )

        # Build the response with product details
        products = [
            {
                "cartitemId": cart_item.cartItemId,
                "product_id": product.productId,
                "product_image":product.imageUrl,
                "product_name": product.name,
                "product_price": product.price if product.price is not None else 0,  # Ensure price is valid
                "quantity": cart_item.quantity,
                "inventory":product.inventory,
                "total_price": (product.price * cart_item.quantity) if product.price is not None else 0  # Ensure total price is valid
            }
            for cart_item, product in cart_items
        ]

        return {"message": "Cart fetched successfully.", "products": products}
    
    except Exception as e:
        # Log the error and return a message
        print(f"Error: {str(e)}")
        return {"message": f"Error occurred: {str(e)}"}

    



    
          
          
     


