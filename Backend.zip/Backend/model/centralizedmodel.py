from sqlalchemy.ext.declarative import declarative_base
from dbconnection.dbConn import engine

Base = declarative_base()

from model.user_model import User
from model.order_model import Order
from model.product_model import Product
from model.cart_model import Cart,CartItem


# Create all tables
Base.metadata.create_all(engine)
