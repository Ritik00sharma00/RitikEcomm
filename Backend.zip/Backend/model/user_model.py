from sqlalchemy import String, Column, Integer, ForeignKey, Float, DateTime
from model.centralizedmodel import Base
from sqlalchemy.orm import relationship
from datetime import datetime
from dbconnection.dbConn import engine



# User Model
class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, autoincrement=True, primary_key=True)
    name = Column(String)
    email = Column(String)
    password = Column(String)
    age = Column(Integer)
    role=Column(String,default="user")
    city=Column(String)
    gender=Column(String)
    mobileNumber = Column(String)
    address = Column(String)

    # Relationship to Cart
    cart = relationship('Cart', back_populates="user", cascade="all, delete-orphan")

    # Relationship to Order
    orders = relationship("Order", back_populates="users")

  
