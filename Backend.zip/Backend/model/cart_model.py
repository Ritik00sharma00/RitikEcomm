from sqlalchemy import Column, Integer, ForeignKey
from sqlalchemy.orm import relationship
from model.centralizedmodel import Base

# Cart Model
class Cart(Base):
    __tablename__ = 'cart'  # Ensure this matches the foreign key reference in CartItem
    
    cartId = Column(Integer, primary_key=True, autoincrement=True)
    userId = Column(Integer, ForeignKey("users.id"), nullable=False)  # ForeignKey to User


    user = relationship('User', foreign_keys=[userId], back_populates='cart')
    cart_items = relationship('CartItem', back_populates='cart')


# CartItem Model
class CartItem(Base):
    __tablename__ = 'cart_items'
    
    cartItemId = Column(Integer, primary_key=True, autoincrement=True)
    cartId = Column(Integer, ForeignKey('cart.cartId'), nullable=False)  # ForeignKey to Cart
    productId = Column(Integer,ForeignKey('Products.productId'), nullable=False)
    quantity = Column(Integer, nullable=False)
    
    product = relationship("Product", back_populates="prod_cart")  # This matches Product's prod_cart
    cart = relationship("Cart", back_populates="cart_items") 