from sqlalchemy import String, Column, Integer, Float, Text, DateTime
from sqlalchemy.ext.declarative import declarative_base
from dbconnection.dbConn import engine  # Assuming your engine is properly set up
from sqlalchemy.orm import relationship
from model.centralizedmodel import Base

# Base = declarative_base()

class Product(Base):

    __tablename__ = 'Products'
    
    productId = Column(Integer, primary_key=True)  # Assuming productId is a unique identifier
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    imageUrl = Column(Text, nullable=False)  # URL for the image
    category = Column(String(255), nullable=False)
    subcategory = Column(String(255), nullable=True)
    inventory = Column(Integer, nullable=False, default=0)
    rating = Column(Float, nullable=False)
    itemsSold = Column(Integer, nullable=False, default=0)  # Renamed from reviews to itemsSold
    dimensions = Column(Text, nullable=True)
    price=Column(Float,nullable=True)  # Storing dimensions as JSON or text
    createdAt = Column(DateTime, nullable=False)
    updatedAt = Column(DateTime, nullable=False)

    orders = relationship("Order", back_populates="product_order") 

    prod_cart = relationship("CartItem", back_populates="product")  

    def __init__(self, productId, name, description, imageUrl, category, subcategory, inventory, rating, itemsSold, dimensions,price, createdAt, updatedAt):
        self.productId = productId
        self.name = name
        self.description = description
        self.imageUrl = imageUrl
        self.category = category
        self.subcategory = subcategory
        self.inventory = inventory
        self.rating = rating
        self.itemsSold = itemsSold
        self.dimensions = dimensions
        self.price=price
        self.createdAt = createdAt
        self.updatedAt = updatedAt
