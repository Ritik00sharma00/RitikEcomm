from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime
from dbconnection.dbConn import engine
from model.centralizedmodel import Base
from datetime import datetime, timedelta

class Order(Base):
    __tablename__ = "orders"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    userid = Column(Integer, ForeignKey("users.id"), nullable=False)
    product_id = Column(Integer, ForeignKey("Products.productId"), nullable=False)
    quantity = Column(Integer, nullable=False)
    total_price = Column(Float, nullable=False)
    status = Column(String, nullable=False)
    order_date = Column(DateTime, nullable=False, default=datetime.utcnow)
    delivered_on = Column(DateTime, nullable=True)  
    order_location = Column(String, nullable=True)  
    payment_mode = Column(String, nullable=False)  # e.g., 'Credit Card', 'PayPal', etc.
    payment_status = Column(String, nullable=False)  # e.g., 'Paid', 'Pending', 'Failed'

    # Relationships
    
    users = relationship("User", back_populates="orders")
    product_order = relationship("Product", back_populates="orders")  

